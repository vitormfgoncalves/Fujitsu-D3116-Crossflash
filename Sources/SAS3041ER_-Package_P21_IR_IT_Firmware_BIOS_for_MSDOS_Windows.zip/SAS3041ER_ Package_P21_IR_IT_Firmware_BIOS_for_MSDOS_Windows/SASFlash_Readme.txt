Use the DOS version of SASFlash.EXE to update the firmware and BIOS for the LSI SAS HBAs.  If the HBA has firmware older than 1.22.01 you must boot to DOS in order to upgrade the firmware.  

To update the firmware and BIOS in the same command line use the following.
sasflash -f <firmware_name>.fw -b <BIOS_name>.ROM


The following steps demonstrate the use of the batch file included in the firmware package.

1) Make a bootable DOS disk (either floppy or USB)

2) If using floppy disks, prepare a second blank floppy to extract the contents of the download zip onto.  The files in the download zip file will not fit on the boot diskette.

3) Down load the firmware files from the web site for the appropriate HBA
      http://www.lsi.com/cm/DownloadSearch.do?locale=EN , select your BOARD, select 

4) Extract the files from the .zip for the board you are updating to the bootable disk.
      example SAS3442X.zip

5) Boot the system where the HBA is installed with the bootable DOS disk

6) Run the hbaFlash.bat utility

7) Follow the instructions.  You must decide which type of firmware you want to install:

 - Integrated RAID (IR) or 
 - Initiator-Target (IT) 

You must also supply the chip version, which will be displayed on screen. See the example below.


Welcome to LSI Logic Integrated SAS Flash Utility
     This Utility will upgrade your LSI SAS3442E HBA 

     Integrated RAID ( IR ) or Initiator ( IT ) Firmware

    For IR     Type   R or r
    For IT     Type   T or t
    To Exit    Type   q

Enter R, T or q 

 ****************************************************************************
    LSI Logic Corp. SAS FLASH Utility.
    SASFlash Version 1.03.07.00 (2007.01.30) 
    Copyright (c) 2006 LSI Logic Corporation. All rights reserved.
 ****************************************************************************
              Adapter Selected is a LSI SAS 1068E(B2)
    
Num   Controller      FW Ver                       NV Ver        BIOS Ver              PCI Addr
    ------------------------------------------------------------------------------------------------------
    1         1068E(B2)   01.18.00.00                25.0b          06.12.00.00          01:00:00
  
          Finished Processing Commands Successfully.
          Exiting SASFlash

    The above shows which chip is on the HBA
    For 1068E(B1)  Type  1
    For 1068E(B2)  Type  2
    To Exit       Type  q

Enter 1, 2 or q 

  You have selected 3442E IR firmware with chip B1
    To Flash    Type  F or f
    To Exit      Type Q or  q
Enter F or Q 

sasflash -f 3442ERB1.fw -b MPTSAS.ROM
