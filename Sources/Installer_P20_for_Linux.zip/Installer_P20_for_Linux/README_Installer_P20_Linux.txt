************************************

Installer for Linux

LSI Corporation SAS2FLASH Release

************************************
=============================
Contents-
=============================
Installer fOr Linux (SAS2FLASH)    :  \sas2flash_linux_i686_x86-64_rel\sas2flash    Version:20.00.00.00        Release Date:18-SEP-14
Installer fOr Linux (SAS2FLASH)    :  \sas2flash_linux_ppc64_rel\sas2flash          Version:20.00.00.00        Release Date:18-SEP-14
README_FOR_Installer_P20_Linux.txt
SAS2Flash_ReferenceGuide.pdf
SAS2FLASH_Phase20.0-20.00.00.00.pdf



Installation:
=============

SAS2FLASH is stand-alone binary and can be executed from any location on a file system.For more details on installer please refer to the SAS2FLASH User manual included in this package.


